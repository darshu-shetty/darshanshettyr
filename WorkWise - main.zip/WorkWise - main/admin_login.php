<?php
session_start();

$con = mysqli_connect("127.0.0.1:3306", "root", "", "freelancer");

$login_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$email = $_POST['email'];
	$pass = $_POST['password'];

	$result = mysqli_query($con, "SELECT * FROM admin where id='$email' and pass='$pass'");

	$nor = mysqli_num_rows($result);

	if ($nor > 0) {
		$row = mysqli_fetch_array($result);

		$_SESSION['admin_username'] = $row['id'];
		$_SESSION['admin_userid'] = $row['sr_no'];

		header('Location: admin_projectlist.php');
		exit();

	} else {
		$login_message = "Error in Login...";
	}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">

	<title>Admin Login </title>
	<!-- Loading third party fonts -->
	<link href="http://fonts.googleapis.com/css?family=Titillium+Web:200,300,400,700|" rel="stylesheet" type="text/css">
	<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
	<!-- Loading main css file -->
	<link rel="stylesheet" href="style.css">

	<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

</head>


<body class="homepage">

	<div id="site-content">

		<header class="site-header">
			<div class="container">
				<div id="branding">
					<img src="images/logo.png" alt="" class="logo">
					<h1 class="site-title"><a href="index.php">WORKWISE</a></h1>
					<small class="site-description">GET WORK.. GET PAID..</small>
				</div>
			</div>
		</header> <!-- .site-header -->

		<main class="main-content">
			<div class="hero heroM">
				<div class="hero-half-background" data-bg-image="dummy/hero.jpg"></div>
				<div class="container">
					<div class="row">
						<div class="col-md-5">
							<div class="hero-content heroM">
								<h2 class="hero-title">
									Hire expert freelancers</h2>

								<span class="arrow"></span>
							</div>
						</div> <!-- .col-md-5 -->
						<div class="col-md-5 col-md-offset-2">
							<div class="request-form">
								<h2>Login</h2>
								<p style="color:yellow;">
									<?php

									if ($login_message != "") {
										echo $login_message;
									}

									?>
								</p>

								<form method="post">
									<div class="field-column row">
										<div class="col-sm-6">
											<div class="field">
												<label for="">Email:</label>
												<input type="text" name="email">
											</div>
										</div>
										<div class="col-sm-6">
											<div class="field">
												<label for="">Password:</label>
												<input type="password" name="password">
											</div>
										</div>
									</div>



									<input type="submit" value="Login">

								</form>
							</div> <!-- .request-form -->
						</div> <!-- .col-md-5 -->
					</div> <!-- .row -->
				</div> <!-- .container -->
			</div> <!-- .hero -->

			<div class="container">


				<div class="cta">
					<header>
						<h2 class="section-title"> </h2>
						<p class="section-desc"> </p>
					</header>

					<p><a href="tel:1234567890" class="tel">Call us:1234567890</a></p>
					<p><a href="mailto:office@freelancer.com" class="email">office@workwise.com</a></p>

				</div>
			</div> <!-- .container -->
	</div> <!-- .fullwidth-block -->
	</main> <!-- .main-content -->

	<footer class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="widget">
						<h3 class="widget-title">Contact</h3>
						<strong>WORKWISE</strong>
						<address>Bangalore</address>
						<a href="tel:1234567890">1234567890</a> <br>
						<a href="mailto:office@freelancer.com">office@workwise.com</a>
					</div> <!-- .widget-title -->
				</div>
				<div class="col-md-4">
					<div class="widget">
						<h3 class="widget-title">Social Media</h3>
						<div class="social-links">
							<a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
							<a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
							<a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
							<a href="#" class="pinterest"><i class="fa fa-pinterest"></i></a>
						</div>
					</div> <!-- .widget-title -->
				</div>
				<div class="col-md-4">
					<div class="widget">
						<h3 class="widget-title">Join US</h3>
						<form action="#" class="subscribe">
							<input type="email" placeholder="Enter your email...">
							<input type="submit" value="sign up">
						</form>
					</div> <!-- .widget-title -->
				</div>
			</div> <!-- .row -->
			<div class="copy">
				<p>Copyright 2023 WORKWISE, All rights reserved</p>
			</div>
		</div> <!-- .container -->
	</footer> <!-- .site-footer -->

	</div> <!-- #site-content -->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/plugins.js"></script>
	<script src="js/app.js"></script>

</body>

</html>