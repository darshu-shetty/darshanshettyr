from django.core.mail import send_mail
import os
from django.conf import settings
from firebase_admin import messaging

def app_constants(request):
    return {
        'APP_NAME': 'Player Prediction',
        'skill_levels':[
            {'key':'1', 'value':'Unsatisfactory'},
            {'key':'2', 'value':'Needs Improvement'},
            {'key':'3', 'value':'Average'},
            {'key':'4', 'value':'Above Average'},
            {'key':'5', 'value':'Excellent'},
        ],
        'skill_groups': {
            'Technical Ability':[
                {'key':'ball_control', 'label':'Ball Control'},
                {'key':'passing', 'label':'Passing'},
                {'key':'dribbling', 'label':'Dribbling'},
                {'key':'heading', 'label':'Heading'},
                {'key':'finishing', 'label':'Finishing'},
            ],
            'Tactical Awareness':[
                {'key':'in_attack', 'label':'In Attack'},
                {'key':'in_defense', 'label':'In Defense'},
            ],
            'Physical Aspects':[
                {'key':'endurance', 'label':'Endurance'},
                {'key':'speed', 'label':'Speed'},
                {'key':'agility', 'label':'Agility'},
                {'key':'strength', 'label':'Strength'},
            ],
            'Personality Traits':[
                {'key':'drive', 'label':'Drive'},
                {'key':'aggressiveness', 'label':'Aggressiveness'},
                {'key':'determination', 'label':'Determination'},
                {'key':'responsibility', 'label':'Responsibility'},
                {'key':'leadership', 'label':'Leadership'},
                {'key':'self_confidence', 'label':'Self Confidence'},
                {'key':'mental_toughness', 'label':'Mental Toughness'},
                {'key':'coach_ability', 'label':'Coach Ability'},
            ]
        }
    }

def deleteImage(filename):
    image_path = os.path.join(settings.MEDIA_ROOT, str(filename))
    if os.path.exists(image_path):
        os.remove(image_path)
        print(f'File removed successfully : {image_path}')    
    print(f'File not found : {image_path}')    


# to send a firebase push notifications
def send_push_notification(token, title, body, data=None):
    message = messaging.Message(
        notification=messaging.Notification(
                title=title,
                body=body,
        ),
        token=token,
        data=data if data else {}
        )
    return messaging.send(message)

def send_password_reset_email(user_email, otp_code, user_first_name):
    subject = "🔐 PlayerPrediction + – Password Reset OTP"
    message = f"""
Dear {user_first_name},

We received a request to reset your password for your PlayerPrediction + Application account.

Your One-Time Password (OTP) for resetting your password is:

🔢 {otp_code}

This OTP is valid for the next 10 minutes. Please do not share it with anyone.

If you did not request this, please ignore this email. Your account remains secure.

Best regards,
PlayerPrediction Support Team
support@PlayerPrediction.com
"""
    send_mail(subject, message, "no-reply@PlayerPrediction.com", [user_email])


