from django.contrib.auth.hashers import make_password
from rest_framework import serializers
from PlayerPredictionApp.models import Player, Performance

class PlayersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Player
        fields = ['id', 'p_name', 'p_contact','p_email','p_age','p_address','p_image', 'p_category','p_is_active', 'p_is_selected']

class PerformanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Performance
        fields = ['player', 'technical_ability', 'tactical_awareness', 'physical_aspects', 'personality_traits']