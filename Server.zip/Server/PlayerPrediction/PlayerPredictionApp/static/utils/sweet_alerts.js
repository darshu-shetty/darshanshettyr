const TIME_OUT = 2000;

const sweetAlert = Swal.mixin({
    // customClass: {
    //     confirmButton: 'btn btn-success',
    //     cancelButton: 'btn btn-danger'
    //   },
    //   buttonsStyling: false
    buttonsStyling: true
});

const sweetToast = Swal.mixin({
    toast: true,
    position: 'top-end',  // Adjust position (top-end, top-start, bottom-end, etc.)
    showConfirmButton: false,
    timer: 3000,  // Auto close after 3 seconds
    timerProgressBar: true,
});

const showSuccess = (message) => {
    // sweetAlert.fire({
    //     title: 'Success',
    //     text: message,
    //     icon: 'success',
    //     confirmButtonText: 'OK'
    // });
    sweetToast.fire({
        icon: 'success',
        title: message
    });
}

const showError = (message) => {
    // sweetAlert.fire({
    //     title: 'Error',
    //     text: message,
    //     icon: 'error',
    //     confirmButtonText: 'OK'
    // });
    sweetToast.fire({
        icon: 'error',
        title: message
    });
}

const showConfirmation = (message, callback) => {
    sweetAlert.fire({
        title: 'Confirmation',
        text: message,
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed) {
            // Execute callback function if user clicks Yes
            callback();
        }
    });
}

const showProcessingAlert = (text) => {
    sweetAlert.fire({
        title: 'Processing',
        text: text,
        icon: 'info',
        showConfirmButton: false,
        confirmButtonText: 'OK',
        showCloseButton: true,
        allowOutsideClick: false, // Disables close on outside click
        onBeforeOpen: () => {
            Swal.showLoading();
        },
    });
}

const closeProcessingAlert = () => {
    Swal.close();
}