package com.example.playerprediction.features.ui.performance.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.ui.performance.AddPerformance;
import com.example.playerprediction.features.ui.players.PlayerDetails;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class PerformanceAdapter extends RecyclerView.Adapter<PerformanceAdapter.ViewHolder> {

    private final Context context;
    private List<PlayerModel> playerModelList;

    public PerformanceAdapter(Context context, List<PlayerModel> playerModelList) {
        this.context = context;
        this.playerModelList = playerModelList;
    }

    @NonNull
    @Override
    public PerformanceAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_player_performance, parent, false);
        return new PerformanceAdapter.ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull PerformanceAdapter.ViewHolder holder, int position) {
        PlayerModel playerModel = playerModelList.get(position);
        holder.playerName.setText(playerModel.getPlayerName());
        holder.playerAge.setText("Age: " + playerModel.getPlayerAge());
        holder.playerCategory.setText(playerModel.getPlayerCategory());
        Utils.loadImage(context, playerModel.getPlayerImage(), holder.playerImage);

        holder.btnAddPerformance.setOnClickListener(view -> {
            // Handle add performance button click
            Intent intent = new Intent(context, AddPerformance.class);
            intent.putExtra("playerId", playerModel.getPlayerId());
            context.startActivity(intent);
        });

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, PlayerDetails.class);
            intent.putExtra("playerId", playerModel.getPlayerId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return playerModelList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ShapeableImageView playerImage;
        private final TextView playerName, playerAge;
        private final Chip playerCategory;
        private final View btnAddPerformance;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            playerImage = itemView.findViewById(R.id.player_image);
            playerName = itemView.findViewById(R.id.player_name);
            playerAge = itemView.findViewById(R.id.player_age);
            playerCategory = itemView.findViewById(R.id.player_category);
            btnAddPerformance = itemView.findViewById(R.id.btn_add_performance);
        }
    }
}
