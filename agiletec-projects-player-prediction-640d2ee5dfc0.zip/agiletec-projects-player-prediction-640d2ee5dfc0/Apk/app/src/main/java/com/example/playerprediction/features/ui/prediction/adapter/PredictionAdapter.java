package com.example.playerprediction.features.ui.prediction.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.ui.players.PlayerDetails;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class PredictionAdapter extends RecyclerView.Adapter<PredictionAdapter.ViewHolder> {
    private final Context context;
    private List<PlayerModel> playerModelList;
    private RequestHandler requestHandler;

    public PredictionAdapter(Context context, List<PlayerModel> playerModelList) {
        this.context = context;
        this.playerModelList = playerModelList;
        requestHandler = new RequestHandler();
    }

    @NonNull
    @Override
    public PredictionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_player_predict, parent, false);
        return new PredictionAdapter.ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull PredictionAdapter.ViewHolder holder, int position) {
        PlayerModel playerModel = playerModelList.get(position);
        holder.playerName.setText(playerModel.getPlayerName());
        holder.playerAge.setText("Age: " + playerModel.getPlayerAge());
        holder.playerCategory.setText(playerModel.getPlayerCategory());
        Utils.loadImage(context, playerModel.getPlayerImage(), holder.playerImage);

        if (playerModel.isSelected() == 1) {
            holder.playerSelectionStatus.setChipBackgroundColorResource(R.color.purple_200);
            holder.playerSelectionStatus.setText("Selected");
        } else {
            holder.playerSelectionStatus.setText("Not Selected");
            holder.playerSelectionStatus.setChipBackgroundColorResource(R.color.md_theme_error);
        }
        holder.predictButton.setOnClickListener(view -> {
            // Handle prediction button click
            predictPlayer(holder.progressBar, holder.predictButton, playerModel, position);
        });

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, PlayerDetails.class);
            intent.putExtra("playerId", playerModel.getPlayerId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return playerModelList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ShapeableImageView playerImage;
        private final TextView playerName, playerAge;
        private final Chip playerSelectionStatus, playerCategory;
        private final Button predictButton;
        private final ProgressBar progressBar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            playerImage = itemView.findViewById(R.id.player_image);
            playerName = itemView.findViewById(R.id.player_name);
            playerAge = itemView.findViewById(R.id.player_age);
            playerSelectionStatus = itemView.findViewById(R.id.player_selection_status);
            playerCategory = itemView.findViewById(R.id.player_category);
            predictButton = itemView.findViewById(R.id.btn_predict);
            progressBar = itemView.findViewById(R.id.progress_prediction);
        }
    }

    private void predictPlayer(ProgressBar progressBar, Button buttonPredict, PlayerModel player, int position) {
        UiHandlers.showProgress(progressBar, buttonPredict);
        requestHandler.predictPlayer(player.getPlayerId(), new ResponseListener<ApiResponse<Boolean>>() {
            @Override
            public void onSuccess(ApiResponse<Boolean> response) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                if (Boolean.TRUE.equals(response.getData())) {
                    if (player.isSelected() == 0) {
                        UiHandlers.AlertDialog(context, "Add player to team ?", response.getMessage(), (dialogInterface, i) -> {
                            playerSelection(player.getPlayerId(), true, progressBar, buttonPredict, position);
                        });
                        return;
                    }
                    UiHandlers.shortToast(context, "Well maintained performance..");
                } else {
                    if (player.isSelected() == 1) {
                        UiHandlers.AlertDialog(context, "Remove player from team ?", response.getMessage(), (dialogInterface, i) -> {
                            playerSelection(player.getPlayerId(), false, progressBar, buttonPredict, position);
                        });
                        return;
                    }
                    UiHandlers.shortToast(context, response.getMessage());
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(context, errorMessage);
            }
        });
    }

    private void playerSelection(int playerId, boolean isSelected, ProgressBar progressBar, Button buttonPredict, int position) {
        UiHandlers.showProgress(progressBar, buttonPredict);
        requestHandler.playerSelection(playerId, isSelected, new ResponseListener<ApiResponse<PlayerModel>>() {
            @Override
            public void onSuccess(ApiResponse<PlayerModel> response) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(context, response.getMessage());
                assert response.getData() != null;
                playerModelList.set(position, response.getData());
                notifyItemChanged(position);
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(context, errorMessage);
            }
        });
    }
}
