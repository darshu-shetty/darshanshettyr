package com.example.playerprediction.features.ui.players;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.features.ui.players.adapters.PlayerAdapter;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;

import java.util.ArrayList;
import java.util.List;

public class PlayersFragment extends Fragment {
    private ProgressBar progressBar;
    private PlayerAdapter playerAdapter;
    private RequestHandler requestHandler;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_players, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressBar = view.findViewById(R.id.progressBar);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        requestHandler = new RequestHandler();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        playerAdapter = new PlayerAdapter(getActivity(), new ArrayList<>());
        recyclerView.setAdapter(playerAdapter);
        fetchData();
    }

    private void fetchData() {
        progressBar.setVisibility(View.VISIBLE);
        requestHandler.getPlayersList(new ResponseListener<ApiResponse<List<PlayerModel>>>() {
            @Override
            public void onSuccess(ApiResponse<List<PlayerModel>> response) {
                progressBar.setVisibility(View.GONE);
                playerAdapter.setPlayerModelList(response.getData());
            }

            @Override
            public void onFailure(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getActivity(), errorMessage);
            }
        });
    }
}