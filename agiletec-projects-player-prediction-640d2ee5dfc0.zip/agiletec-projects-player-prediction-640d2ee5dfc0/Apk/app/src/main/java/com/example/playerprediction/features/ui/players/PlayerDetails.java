package com.example.playerprediction.features.ui.players;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.ui.performance.AddPerformance;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

public class PlayerDetails extends AppCompatActivity {
    private RequestHandler requestHandler;
    private ProgressBar progressBar;
    private LinearLayout mainLayout;

    private ShapeableImageView imageViewPlayer;
    private TextView textViewPlayerName, textViewPlayerAge, textViewPlayerContact, textViewPlayerEmail, textViewPlayerAddress;
    private Chip chipPlayerCategory, chipSelectionStatus;
    private Button buttonPredict;
    private PlayerModel player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_player_details);
        requestHandler = new RequestHandler();

        progressBar = findViewById(R.id.progressBar);
        mainLayout = findViewById(R.id.mainLayout);

        mainLayout.setVisibility(View.GONE);

        Intent intent = getIntent();
        int playerId = intent.getIntExtra("playerId", -1);

        if (playerId == -1) {
            finish();
            return;
        }

        playerAction(playerId);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Player Details");
        toolbar.setNavigationOnClickListener(v -> finish());

        imageViewPlayer = findViewById(R.id.imageViewPlayer);
        textViewPlayerName = findViewById(R.id.textViewPlayerName);
        textViewPlayerAge = findViewById(R.id.textViewPlayerAge);
        textViewPlayerContact = findViewById(R.id.textViewPlayerContact);
        textViewPlayerEmail = findViewById(R.id.textViewPlayerEmail);
        textViewPlayerAddress = findViewById(R.id.textViewPlayerAddress);
        chipPlayerCategory = findViewById(R.id.chipPlayerCategory);
        chipSelectionStatus = findViewById(R.id.chipSelectionStatus);

        buttonPredict = findViewById(R.id.buttonPredict);

        buttonPredict.setOnClickListener(v -> predictPlayer(playerId));

        findViewById(R.id.buttonPerformance).setOnClickListener(v -> {
            Intent intent1 = new Intent(PlayerDetails.this, AddPerformance.class);
            intent1.putExtra("playerId", playerId);
            startActivity(intent1);
        });
    }

    private void predictPlayer(int playerId) {
        UiHandlers.showProgress(progressBar, buttonPredict);
        requestHandler.predictPlayer(playerId, new ResponseListener<ApiResponse<Boolean>>() {
            @Override
            public void onSuccess(ApiResponse<Boolean> response) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                if (Boolean.TRUE.equals(response.getData())) {
                    if (player.isSelected() == 0) {
                        UiHandlers.AlertDialog(PlayerDetails.this, "Add player to team ?", response.getMessage(), (dialogInterface, i) -> {
                            playerSelection(playerId, true);
                        });
                        return;
                    }
                    UiHandlers.shortToast(PlayerDetails.this, "Well maintained performance..");
                } else {
                    if (player.isSelected() == 1) {
                        UiHandlers.AlertDialog(PlayerDetails.this, "Remove player from team ?", response.getMessage(), (dialogInterface, i) -> {
                            playerSelection(playerId, false);
                        });
                        return;
                    }
                    UiHandlers.shortToast(PlayerDetails.this, response.getMessage());
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }

    private void playerAction(int playerId) {
        progressBar.setVisibility(View.VISIBLE);
        requestHandler.getPlayerDetails(playerId, new ResponseListener<ApiResponse<PlayerModel>>() {
            @Override
            public void onSuccess(ApiResponse<PlayerModel> response) {
                progressBar.setVisibility(View.GONE);
                mainLayout.setVisibility(View.VISIBLE);
                assert response.getData() != null;
                player = response.getData();
                updatePlayerDetails(player);
            }

            @Override
            public void onFailure(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }

    private void playerSelection(int playerId, boolean isSelected) {
        UiHandlers.showProgress(progressBar, buttonPredict);
        requestHandler.playerSelection(playerId, isSelected, new ResponseListener<ApiResponse<PlayerModel>>() {
            @Override
            public void onSuccess(ApiResponse<PlayerModel> response) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(PlayerDetails.this, response.getMessage());
                assert response.getData() != null;
                player = response.getData();
                updatePlayerDetails(player);
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, buttonPredict);
                UiHandlers.shortToast(PlayerDetails.this, errorMessage);
            }
        });
    }

    @SuppressLint("SetTextI18n")
    private void updatePlayerDetails(PlayerModel player) {
        textViewPlayerName.setText(player.getPlayerName());
        textViewPlayerAge.setText(player.getPlayerAge() + " years old");
        chipPlayerCategory.setText(player.getPlayerCategory());

        textViewPlayerContact.setText(player.getPlayerContact());
        textViewPlayerEmail.setText(player.getPlayerEmail());
        textViewPlayerAddress.setText(player.getPlayerAddress());
        Utils.loadImage(getApplicationContext(), player.getPlayerImage(), imageViewPlayer);

        if (player.isSelected() == 1) {
            chipSelectionStatus.setChipBackgroundColorResource(R.color.purple_200);
            chipSelectionStatus.setText("Selected");
        } else {
            chipSelectionStatus.setText("Not Selected");
            chipSelectionStatus.setChipBackgroundColorResource(R.color.md_theme_error);
        }
    }
}