package com.example.playerprediction.features.ui.players.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.ui.players.PlayerDetails;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.PlayerViewHolder> {
    private final Context context;
    private List<PlayerModel> playerModelList;

    public PlayerAdapter(Context context, List<PlayerModel> playerModelList) {
        this.context = context;
        this.playerModelList = playerModelList;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setPlayerModelList(List<PlayerModel> playerModelList) {
        this.playerModelList = playerModelList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PlayerAdapter.PlayerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_player, parent, false);
        return new PlayerAdapter.PlayerViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull PlayerAdapter.PlayerViewHolder holder, int position) {
        PlayerModel player = playerModelList.get(position);
        holder.playerName.setText(player.getPlayerName());
        holder.playerEmail.setText(player.getPlayerEmail());
        holder.playerAge.setText("Age: " + player.getPlayerAge());
        holder.playerCategory.setText(player.getPlayerCategory());
        Utils.loadImage(context, player.getPlayerImage(), holder.playerImage);

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, PlayerDetails.class);
            intent.putExtra("playerId", player.getPlayerId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return playerModelList.size();
    }

    public static class PlayerViewHolder extends RecyclerView.ViewHolder {
        private ShapeableImageView playerImage;
        private TextView playerName, playerEmail, playerAge;
        private Chip playerCategory;

        public PlayerViewHolder(@NonNull View itemView) {
            super(itemView);
            playerImage = itemView.findViewById(R.id.player_image);
            playerName = itemView.findViewById(R.id.player_name);
            playerEmail = itemView.findViewById(R.id.player_email);
            playerAge = itemView.findViewById(R.id.player_age);
            playerCategory = itemView.findViewById(R.id.player_category);
        }
    }
}
