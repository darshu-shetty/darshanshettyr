package com.example.playerprediction.features.ui.performance.models;

import java.util.ArrayList;
import java.util.List;

public class Skill {
    private String key;
    private String label;
    private String selectedLevel;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getSelectedLevel() {
        return selectedLevel;
    }

    public void setSelectedLevel(String selectedLevel) {
        this.selectedLevel = selectedLevel;
    }

    public Skill(String key, String label) {
        this.key = key;
        this.label = label;
    }

    public static List<Skill> getTechnicalAbility() {
        List<Skill> skills = new ArrayList<>();
        skills.add(new Skill("ball_control", "Ball Control"));
        skills.add(new Skill("passing", "Passing"));
        skills.add(new Skill("dribbling", "Dribbling"));
        skills.add(new Skill("heading", "Heading"));
        skills.add(new Skill("finishing", "Finishing"));
        return skills;
    }

    public static List<Skill> getTacticalAwareness() {
        List<Skill> skills = new ArrayList<>();
        skills.add(new Skill("in_attack", "In Attack"));
        skills.add(new Skill("in_defense", "In Defense"));
        return skills;
    }

    public static List<Skill> getPhysicalAspects() {
        List<Skill> skills = new ArrayList<>();
        skills.add(new Skill("endurance", "Endurance"));
        skills.add(new Skill("speed", "Speed"));
        skills.add(new Skill("agility", "Agility"));
        skills.add(new Skill("strength", "Strength"));
        return skills;
    }

    public static List<Skill> getPersonalityTraits() {
        List<Skill> skills = new ArrayList<>();
        skills.add(new Skill("drive", "Drive"));
        skills.add(new Skill("aggressiveness", "Aggressiveness"));
        skills.add(new Skill("determination", "Determination"));
        skills.add(new Skill("responsibility", "Responsibility"));
        skills.add(new Skill("leadership", "Leadership"));
        skills.add(new Skill("self_confidence", "Self Confidence"));
        skills.add(new Skill("mental_toughness", "Mental Toughness"));
        skills.add(new Skill("coach_ability", "Coach Ability"));
        return skills;
    }


}
