package com.example.playerprediction.features.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.models.UserSession;
import com.example.playerprediction.common.utils.SharedPref;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.HomeActivity;
import com.example.playerprediction.features.auth.models.LoginRequest;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;
import com.google.firebase.messaging.FirebaseMessaging;

public class LoginActivity extends AppCompatActivity {
    private Button Login;
    private EditText Email, Password;
    private ProgressBar progressBar;
    private RequestHandler requestHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        requestHandler = new RequestHandler();

        Email = findViewById(R.id.login_email);
        Password = findViewById(R.id.login_password);
        Login = findViewById(R.id.login_submit);
        progressBar = findViewById(R.id.progressBar);
        Button forgotPassword = findViewById(R.id.userForgot);

        Login.setOnClickListener(view -> {
            if (isValidated()) {
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(command -> {
                    if (!command.isSuccessful()) {
                        System.out.println("Fetching FCM registration token failed");
                        return;
                    }
                    String token = command.getResult();
                    loginUser(token);
                });
            }
        });
        forgotPassword.setOnClickListener(view -> {
            startActivity(new Intent(this, ForgotPassword.class));
        });
    }

    private void loginUser(String token) {
        String deviceId = Utils.getDeviceId(getApplicationContext());
        LoginRequest request = new LoginRequest(
                Email.getText().toString(),
                Password.getText().toString(),
                token, deviceId
        );
        UiHandlers.showProgress(progressBar, Login);

        requestHandler.loginUser(request, new ResponseListener<ApiResponse<UserSession>>() {
            @Override
            public void onSuccess(ApiResponse<UserSession> response) {
                UiHandlers.hideProgress(progressBar, Login);
                if (response.isSuccess()) {
                    UiHandlers.shortToast(getApplicationContext(), "Login Successful..");
                    SharedPref.setIsAuthenticated(getApplicationContext(), true);
                    SharedPref.saveUserSession(getApplicationContext(), response.getData());
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    return;
                }
                UiHandlers.shortToast(getApplicationContext(), response.getMessage());
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, Login);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }


    private boolean isValidated() {
        if (Email.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Email id is required");
            return false;
        }
        if (Password.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Password is required");
            return false;
        }
        return true;
    }
}