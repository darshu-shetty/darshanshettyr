package com.example.playerprediction.common.utils;

import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class UiHandlers {
    public static void AlertDialog(Context context, String title, String msg, final DialogInterface.OnClickListener listener) {
        MaterialAlertDialogBuilder materialAlertDialogBuilder = new MaterialAlertDialogBuilder(context);
        materialAlertDialogBuilder.setTitle(title)
                .setMessage(msg)
                .setPositiveButton("OK", (dialogInterface, i) -> {
                    if (listener != null) {
                        listener.onClick(dialogInterface, i);
                    }
                })
                .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss())
                .show();
    }

    public static void shortToast(Context context, String message) {
        if (context != null) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }
    }

    public static void longToast(Context context, String message) {
        if (context != null) {
            Toast.makeText(context, message, Toast.LENGTH_LONG).show();
        }
    }


    public static void showProgress(ProgressBar progressBar, Button button) {
        button.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
    }
    public static void hideProgress(ProgressBar progressBar, Button button) {
        button.setEnabled(true);
        progressBar.setVisibility(View.INVISIBLE);
    }
}
