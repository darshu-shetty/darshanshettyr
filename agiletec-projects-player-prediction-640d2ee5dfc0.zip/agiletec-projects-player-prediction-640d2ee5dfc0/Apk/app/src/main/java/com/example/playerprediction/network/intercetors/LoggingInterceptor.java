package com.example.playerprediction.network.intercetors;

import androidx.annotation.NonNull;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class LoggingInterceptor implements Interceptor {
    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request request = chain.request();
        long startTime = System.nanoTime();
        System.out.println("Sending request: " + request.url());

        Response response = chain.proceed(request);
        long endTime = System.nanoTime();
        System.out.println("Received response in " + (endTime - startTime) / 1e6 + " ms");

        return response;
    }
}
