package com.example.playerprediction.features.ui.performance.models;

import java.util.ArrayList;
import java.util.List;

public class SkillLevel {
    private String key;
    private String value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public SkillLevel(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static List<SkillLevel> getSkillLevels() {
        List<SkillLevel> levels = new ArrayList<>();
        levels.add(new SkillLevel("1", "Unsatisfactory"));
        levels.add(new SkillLevel("2", "Needs Improvement"));
        levels.add(new SkillLevel("3", "Average"));
        levels.add(new SkillLevel("4", "Above Average"));
        levels.add(new SkillLevel("5", "Excellent"));
        return levels;
    }
}
