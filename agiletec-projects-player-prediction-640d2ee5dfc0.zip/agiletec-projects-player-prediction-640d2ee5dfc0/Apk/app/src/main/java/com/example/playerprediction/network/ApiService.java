package com.example.playerprediction.network;

import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.models.UserSession;
import com.example.playerprediction.features.auth.models.*;
import com.example.playerprediction.features.ui.performance.models.PerformanceData;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.features.ui.team.models.TeamPlayerModel;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.*;


public interface ApiService {
    @POST("auth/login/")
    Call<ApiResponse<UserSession>> loginUser(@Body LoginRequest loginRequest);

    @POST("auth/send-otp/")
    Call<ApiResponse<String>> sendOtp(@Body SendOtpRequest otpRequest);

    @POST("auth/verify-otp/")
    Call<ApiResponse<Void>> verifyOtp(@Body VerifyOtpRequest verifyOtpRequest);

    @GET("player/")
    Call<ApiResponse<List<PlayerModel>>> getPlayers();

    @GET("player/")
    Call<ApiResponse<PlayerModel>> getPlayerDetails(
            @Query("playerId") int playerId
    );

    @FormUrlEncoded
    @POST("player/")
    Call<ApiResponse<PlayerModel>> playerSelection(
            @Field("playerId") int playerId,
            @Field("selectPlayer") boolean selectPlayer
    );

    @GET("team/")
    Call<ApiResponse<List<TeamPlayerModel>>> getTeamPlayers();

    @FormUrlEncoded
    @POST("prediction/")
    Call<ApiResponse<Boolean>> predictPlayer(
            @Field("playerId") int playerId
    );

    @POST("performance/")
    Call<ApiResponse<Void>> addPerformance(@Body PerformanceData data);

}
