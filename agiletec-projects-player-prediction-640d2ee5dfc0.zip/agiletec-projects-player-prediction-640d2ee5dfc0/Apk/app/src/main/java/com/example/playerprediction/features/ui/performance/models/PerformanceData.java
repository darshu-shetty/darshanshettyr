package com.example.playerprediction.features.ui.performance.models;

import java.util.Map;

public class PerformanceData {
    private Map<String, Map<String, String>> data;
    private int playerId;

    public PerformanceData(Map<String, Map<String, String>> data, int playerId) {
        this.data = data;
        this.playerId = playerId;
    }

    public Map<String, Map<String, String>> getData() {
        return data;
    }

    public int getPlayerId() {
        return playerId;
    }
}
