package com.example.playerprediction;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.playerprediction.common.utils.PermissionUtils;
import com.example.playerprediction.common.utils.SharedPref;
import com.example.playerprediction.features.HomeActivity;
import com.example.playerprediction.features.auth.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (!PermissionUtils.hasPermissions(this)) {
            // Request permissions if not granted
            PermissionUtils.requestPermissions(this);
        }
        Intent intent;
        boolean isAuthenticated = SharedPref.getIsAuthenticated(this);
        if (isAuthenticated) {
            intent = new Intent(this, HomeActivity.class);
        } else {
            intent = new Intent(this, LoginActivity.class);
        }
        new Handler().postDelayed(() ->
        {
            startActivity(intent);
            finish();
        }, 2500);
    }
}