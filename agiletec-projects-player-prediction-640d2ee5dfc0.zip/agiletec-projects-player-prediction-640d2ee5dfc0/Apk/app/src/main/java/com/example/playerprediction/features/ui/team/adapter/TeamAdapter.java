package com.example.playerprediction.features.ui.team.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.utils.Utils;
import com.example.playerprediction.features.ui.players.PlayerDetails;
import com.example.playerprediction.features.ui.players.adapters.PlayerAdapter;
import com.example.playerprediction.features.ui.team.models.TeamPlayerModel;
import com.google.android.material.chip.Chip;
import com.google.android.material.imageview.ShapeableImageView;

import java.util.List;

public class TeamAdapter extends RecyclerView.Adapter<TeamAdapter.ViewHolder> {

    private final Context context;
    private List<TeamPlayerModel> teamPlayerModelList;

    public TeamAdapter(Context context, List<TeamPlayerModel> teamPlayerModelList) {
        this.context = context;
        this.teamPlayerModelList = teamPlayerModelList;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setTeamPlayerModelList(List<TeamPlayerModel> teamPlayerModelList) {
        this.teamPlayerModelList = teamPlayerModelList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TeamAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_team_player, parent, false);
        return new TeamAdapter.ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull TeamAdapter.ViewHolder holder, int position) {
        TeamPlayerModel team = teamPlayerModelList.get(position);
        holder.textViewPlayerName.setText(team.getPlayerName());
        holder.textViewPlayerAge.setText("Age: " + team.getPlayerAge());
        holder.chipPlayerPosition.setText(team.getPlayerCategory());
        // Load player image using a library like Glide or Picasso
        Utils.loadImage(context, team.getPlayerImage(), holder.imageViewPlayer);

        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(context, PlayerDetails.class);
            intent.putExtra("playerId", team.getPlayerId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return teamPlayerModelList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textViewPlayerName, textViewPlayerAge;
        private final Chip chipPlayerPosition;
        private final ShapeableImageView imageViewPlayer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewPlayerName = itemView.findViewById(R.id.textViewPlayerName);
            textViewPlayerAge = itemView.findViewById(R.id.textViewPlayerAge);
            chipPlayerPosition = itemView.findViewById(R.id.chipPlayerPosition);
            imageViewPlayer = itemView.findViewById(R.id.imageViewPlayer);
        }
    }
}
