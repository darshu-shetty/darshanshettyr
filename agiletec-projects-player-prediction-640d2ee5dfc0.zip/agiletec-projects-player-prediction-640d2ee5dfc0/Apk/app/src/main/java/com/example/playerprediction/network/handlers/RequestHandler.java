package com.example.playerprediction.network.handlers;

import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.models.UserSession;
import com.example.playerprediction.features.auth.models.LoginRequest;
import com.example.playerprediction.features.auth.models.SendOtpRequest;
import com.example.playerprediction.features.auth.models.VerifyOtpRequest;
import com.example.playerprediction.features.ui.performance.models.PerformanceData;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.features.ui.team.models.TeamPlayerModel;

import java.util.List;
import java.util.Map;

import retrofit2.Call;

public class RequestHandler extends BaseRequestHandler {
    public void loginUser(LoginRequest loginRequest, ResponseListener<ApiResponse<UserSession>> listener) {
        Call<ApiResponse<UserSession>> call = apiService.loginUser(loginRequest);
        enqueueCall(call, listener);
    }

    public void sendOtp(SendOtpRequest otpRequest, ResponseListener<ApiResponse<String>> listener) {
        Call<ApiResponse<String>> call = apiService.sendOtp(otpRequest);
        enqueueCall(call, listener);
    }

    public void verifyOtp(VerifyOtpRequest verifyOtpRequest, ResponseListener<ApiResponse<Void>> listener) {
        Call<ApiResponse<Void>> call = apiService.verifyOtp(verifyOtpRequest);
        enqueueCall(call, listener);
    }

    public void getPlayersList(ResponseListener<ApiResponse<List<PlayerModel>>> listener) {
        Call<ApiResponse<List<PlayerModel>>> call = apiService.getPlayers();
        enqueueCall(call, listener);
    }

    public void getTeamPlayersList(ResponseListener<ApiResponse<List<TeamPlayerModel>>> listener) {
        Call<ApiResponse<List<TeamPlayerModel>>> call = apiService.getTeamPlayers();
        enqueueCall(call, listener);
    }

    public void getPlayerDetails(int playerId, ResponseListener<ApiResponse<PlayerModel>> listener) {
        Call<ApiResponse<PlayerModel>> call = apiService.getPlayerDetails(playerId);
        enqueueCall(call, listener);
    }

    public void predictPlayer(int playerId, ResponseListener<ApiResponse<Boolean>> listener) {
        Call<ApiResponse<Boolean>> call = apiService.predictPlayer(playerId);
        enqueueCall(call, listener);
    }

    public void playerSelection(int playerId, boolean selectPlayer, ResponseListener<ApiResponse<PlayerModel>> listener) {
        Call<ApiResponse<PlayerModel>> call = apiService.playerSelection(playerId, selectPlayer);
        enqueueCall(call, listener);
    }

    public void addPerformance(PerformanceData data, ResponseListener<ApiResponse<Void>> listener) {
        Call<ApiResponse<Void>> call = apiService.addPerformance(data);
        enqueueCall(call, listener);
    }
}
