package com.example.playerprediction.features.ui.performance.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.features.ui.performance.models.SkillGroup;
import com.example.playerprediction.features.ui.performance.models.SkillLevel;

import java.util.List;

public class SkillGroupAdapter extends RecyclerView.Adapter<SkillGroupAdapter.GroupViewHolder> {
    private final List<SkillGroup> groupList;
    private final List<SkillLevel> levelList;
    private final Context context;

    public SkillGroupAdapter(List<SkillGroup> groupList, List<SkillLevel> levelList, Context context) {
        this.groupList = groupList;
        this.levelList = levelList;
        this.context = context;
    }

    public List<SkillGroup> getSkillGroups() {
        return groupList;
    }


    @NonNull
    @Override
    public SkillGroupAdapter.GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_skill_group, parent, false);
        return new GroupViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SkillGroupAdapter.GroupViewHolder holder, int position) {
        SkillGroup group = groupList.get(position);
        holder.groupTitle.setText(group.getGroupName());

        SkillItemAdapter adapter = new SkillItemAdapter(group.getSkills(), levelList, context);
        holder.skillRecycler.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
        holder.skillRecycler.setAdapter(adapter);
    }

    @Override
    public int getItemCount() {
        return groupList.size();
    }

    public static class GroupViewHolder extends RecyclerView.ViewHolder {
        TextView groupTitle;
        RecyclerView skillRecycler;

        GroupViewHolder(View itemView) {
            super(itemView);
            groupTitle = itemView.findViewById(R.id.group_title);
            skillRecycler = itemView.findViewById(R.id.skills_recycler);
        }
    }
}
