package com.example.playerprediction.features.ui.performance;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.features.ui.performance.adapters.SkillGroupAdapter;
import com.example.playerprediction.features.ui.performance.models.PerformanceData;
import com.example.playerprediction.features.ui.performance.models.Skill;
import com.example.playerprediction.features.ui.performance.models.SkillGroup;
import com.example.playerprediction.features.ui.performance.models.SkillLevel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddPerformance extends AppCompatActivity {
    private SkillGroupAdapter adapter;
    private RequestHandler requestHandler;
    private ProgressBar progressBar;
    private ExtendedFloatingActionButton save;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_performance);
        requestHandler = new RequestHandler();

        Intent intent = getIntent();
        int playerId = intent.getIntExtra("playerId", -1);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Add Performance");
        toolbar.setNavigationOnClickListener(v -> finish());

        progressBar = findViewById(R.id.progressBar);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        save = findViewById(R.id.savePerformance);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new SkillGroupAdapter(SkillGroup.getAllSkillGroups(), SkillLevel.getSkillLevels(), AddPerformance.this);
        recyclerView.setAdapter(adapter);

        Map<String, Map<String, String>> performanceData = new HashMap<>();

        save.setOnClickListener(v -> {
            List<SkillGroup> skillGroups = adapter.getSkillGroups();
            for (SkillGroup group : skillGroups) {
                String groupName = group.getGroupName();
                Map<String, String> skillMap = new HashMap<>();
                for (Skill skill : group.getSkills()) {
                    if (skill.getSelectedLevel() != null) {
                        skillMap.put(skill.getKey(), skill.getSelectedLevel());
                    }
                }
                performanceData.put(groupName, skillMap);
            }
            UiHandlers.AlertDialog(AddPerformance.this, "Save Performance", "Are you sure you want to save this performance?", (dialog, which) -> {
                savePerformance(playerId, performanceData);
            });
        });


    }

    private void savePerformance(int playerId, Map<String, Map<String, String>> performanceData) {
        UiHandlers.showProgress(progressBar, save);
        PerformanceData performance = new PerformanceData(
                performanceData, playerId
        );
        requestHandler.addPerformance(performance, new ResponseListener<ApiResponse<Void>>() {
            @Override
            public void onSuccess(ApiResponse<Void> response) {
                UiHandlers.hideProgress(progressBar, save);
                UiHandlers.shortToast(AddPerformance.this, response.getMessage());
                finish();
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, save);
                UiHandlers.shortToast(AddPerformance.this, errorMessage);
            }
        });

    }
}