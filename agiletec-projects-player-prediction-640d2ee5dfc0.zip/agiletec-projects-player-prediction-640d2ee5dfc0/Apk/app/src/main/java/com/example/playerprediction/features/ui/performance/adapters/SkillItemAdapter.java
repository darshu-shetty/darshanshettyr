package com.example.playerprediction.features.ui.performance.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.features.ui.performance.models.Skill;
import com.example.playerprediction.features.ui.performance.models.SkillLevel;

import java.util.ArrayList;
import java.util.List;

public class SkillItemAdapter extends RecyclerView.Adapter<SkillItemAdapter.SkillViewHolder> {
    private List<Skill> skillList;
    private List<SkillLevel> levels;
    private final Context context;

    public SkillItemAdapter(List<Skill> skillList, List<SkillLevel> levels, Context context) {
        this.skillList = skillList;
        this.levels = levels;
        this.context = context;
    }

    @NonNull
    @Override
    public SkillItemAdapter.SkillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_skill_input, parent, false);
        return new SkillViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SkillItemAdapter.SkillViewHolder holder, int position) {
        Skill skill = skillList.get(position);
        holder.label.setText(skill.getLabel());

        List<String> levelLabels = new ArrayList<>();
        for (SkillLevel level : levels) levelLabels.add(level.getValue());

        ArrayAdapter<String> adapter = new ArrayAdapter<>(holder.itemView.getContext(), android.R.layout.simple_spinner_dropdown_item, levelLabels);
        holder.spinner.setAdapter(adapter);

        holder.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                skill.setSelectedLevel(levels.get(pos).getKey());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    @Override
    public int getItemCount() {
        return skillList.size();
    }

    public static class SkillViewHolder extends RecyclerView.ViewHolder {
        TextView label;
        Spinner spinner;

        SkillViewHolder(View itemView) {
            super(itemView);
            label = itemView.findViewById(R.id.skill_label);
            spinner = itemView.findViewById(R.id.skill_spinner);
        }
    }
}
