package com.example.playerprediction.features.ui.players.models;

import android.content.Intent;

import com.google.gson.annotations.SerializedName;

public class PlayerModel {
    @SerializedName("id")
    private Integer playerId;

    @SerializedName("p_name")
    private String playerName;

    @SerializedName("p_age")
    private String playerAge;

    @SerializedName("p_category")
    private String playerCategory;

    @SerializedName("p_address")
    private String playerAddress;

    @SerializedName("p_contact")
    private String playerContact;

    @SerializedName("p_email")
    private String playerEmail;

    @SerializedName("p_image")
    private String playerImage;

    @SerializedName("p_is_selected")
    private int isSelected;

    public Integer getPlayerId() {
        return playerId;
    }

    public String getPlayerName() {
        return playerName;
    }

    public String getPlayerAge() {
        return playerAge;
    }

    public String getPlayerCategory() {
        return playerCategory;
    }

    public String getPlayerAddress() {
        return playerAddress;
    }

    public String getPlayerContact() {
        return playerContact;
    }

    public String getPlayerEmail() {
        return playerEmail;
    }

    public String getPlayerImage() {
        return playerImage;
    }

    public int isSelected() {
        return isSelected;
    }
}
