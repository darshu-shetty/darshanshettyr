package com.example.playerprediction.features.ui.performance.models;

import static com.example.playerprediction.features.ui.performance.models.Skill.*;


import java.util.ArrayList;
import java.util.List;

public class SkillGroup {
    private String groupName;
    private List<Skill> skills;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public List<Skill> getSkills() {
        return skills;
    }

    public void setSkills(List<Skill> skills) {
        this.skills = skills;
    }

    public SkillGroup(String groupName, List<Skill> skills) {
        this.groupName = groupName;
        this.skills = skills;
    }

    // Method to return all skill groups
    public static List<SkillGroup> getAllSkillGroups() {
        List<SkillGroup> skillGroups = new ArrayList<>();

        skillGroups.add(new SkillGroup("Technical Ability", getTechnicalAbility()));
        skillGroups.add(new SkillGroup("Tactical Awareness", getTacticalAwareness()));
        skillGroups.add(new SkillGroup("Physical Aspects", getPhysicalAspects()));
        skillGroups.add(new SkillGroup("Personality Traits", getPersonalityTraits()));

        return skillGroups;
    }
}
