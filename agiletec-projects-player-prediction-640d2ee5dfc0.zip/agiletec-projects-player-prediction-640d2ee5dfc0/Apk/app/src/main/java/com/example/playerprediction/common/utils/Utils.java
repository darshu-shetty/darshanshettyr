package com.example.playerprediction.common.utils;


import android.annotation.SuppressLint;
import android.content.Context;
import android.provider.Settings;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.playerprediction.R;

public class Utils {
    @SuppressLint("HardwareIds")
    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static void loadImage(Context context, String imagePath, ImageView imageView) {
        Glide.with(context).load(imagePath).error(R.drawable.app_logo).into(imageView);
    }


}
