package com.example.playerprediction.features.ui.team;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.features.ui.team.adapter.TeamAdapter;
import com.example.playerprediction.features.ui.team.models.TeamPlayerModel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;

import java.util.ArrayList;
import java.util.List;

public class TeamFragment extends Fragment {

    private ProgressBar progressBar;
    private TeamAdapter teamAdapter;
    private RequestHandler requestHandler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_team, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        progressBar = view.findViewById(R.id.progressBar);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        requestHandler = new RequestHandler();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        teamAdapter = new TeamAdapter(getActivity(), new ArrayList<>());
        recyclerView.setAdapter(teamAdapter);
        fetchData();
    }

    private void fetchData() {
        progressBar.setVisibility(View.VISIBLE);
        requestHandler.getTeamPlayersList(new ResponseListener<ApiResponse<List<TeamPlayerModel>>>() {
            @Override
            public void onSuccess(ApiResponse<List<TeamPlayerModel>> response) {
                progressBar.setVisibility(View.GONE);
                teamAdapter.setTeamPlayerModelList(response.getData());
            }

            @Override
            public void onFailure(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getActivity(), errorMessage);
            }
        });
    }
}