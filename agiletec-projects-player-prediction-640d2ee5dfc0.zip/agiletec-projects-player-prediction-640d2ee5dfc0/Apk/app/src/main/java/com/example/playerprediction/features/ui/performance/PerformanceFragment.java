package com.example.playerprediction.features.ui.performance;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.playerprediction.R;
import com.example.playerprediction.common.models.ApiResponse;
import com.example.playerprediction.common.utils.UiHandlers;
import com.example.playerprediction.features.ui.performance.adapters.PerformanceAdapter;
import com.example.playerprediction.features.ui.players.models.PlayerModel;
import com.example.playerprediction.network.handlers.RequestHandler;
import com.example.playerprediction.network.handlers.ResponseListener;

import java.util.List;


public class PerformanceFragment extends Fragment {
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private PerformanceAdapter adapter;
    private RequestHandler requestHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_performance, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        requestHandler = new RequestHandler();
        recyclerView = view.findViewById(R.id.recyclerView);
        progressBar = view.findViewById(R.id.progressBar);

        LinearLayoutManager layoutManager = new LinearLayoutManager(requireActivity());
        recyclerView.setLayoutManager(layoutManager);

        fetchPlayersData();
    }

    private void fetchPlayersData() {
        progressBar.setVisibility(View.VISIBLE);
        requestHandler.getPlayersList(new ResponseListener<ApiResponse<List<PlayerModel>>>() {
            @Override
            public void onSuccess(ApiResponse<List<PlayerModel>> response) {
                progressBar.setVisibility(View.GONE);
                adapter = new PerformanceAdapter(getContext(), response.getData());
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onFailure(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getContext(), errorMessage);
            }
        });
    }
}