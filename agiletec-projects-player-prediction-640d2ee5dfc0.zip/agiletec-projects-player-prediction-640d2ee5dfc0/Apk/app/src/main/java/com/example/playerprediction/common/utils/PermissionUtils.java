package com.example.playerprediction.common.utils;


import static com.example.playerprediction.constants.AppConstants.REQUEST_CODE_PERMISSIONS;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class PermissionUtils {
    @SuppressLint("InlinedApi")
    private static final String[] REQUIRED_PERMISSIONS_ANDROID_13_AND_ABOVE = {
            Manifest.permission.POST_NOTIFICATIONS
    };

    private static final String[] REQUIRED_PERMISSIONS_BELOW_ANDROID_13 = {
    };

    private static String[] getRequiredPermissions() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? REQUIRED_PERMISSIONS_ANDROID_13_AND_ABOVE
                : REQUIRED_PERMISSIONS_BELOW_ANDROID_13;
    }

    public static void requestPermissions(Activity activity) {
        ArrayList<String> permissionsToRequest = new ArrayList<>();

        for (String permission : getRequiredPermissions()) {
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            ActivityCompat.requestPermissions(activity, permissionsToRequest.toArray(new String[0]), REQUEST_CODE_PERMISSIONS);
        }
    }

    public static boolean hasPermissions(Context context) {
        for (String permission : getRequiredPermissions()) {
            if (ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public static void handlePermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, Activity activity) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (!allGranted) {
                UiHandlers.AlertDialog(activity, "Warning !",
                        "Please allow all these permissions? Otherwise you cannot perform actions",
                        (dialog, which) -> requestPermissions(activity));
            }
        }
    }
}
