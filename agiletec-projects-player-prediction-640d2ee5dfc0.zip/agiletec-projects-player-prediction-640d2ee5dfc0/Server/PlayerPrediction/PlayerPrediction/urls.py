"""PlayerPrediction URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from PlayerPredictionApp.views import AuthView, PlayerView, TeamView, PerformanceView, PredictionView, AdminLoginView, AdminPlayerView, AdminPerformanceView, AdminTeamView, index, adminHome, logout


urlpatterns = [
   
    # web urls
    path('', index, name='index'),
    path('logout/', logout, name='logout'),
    path('admin/home/', adminHome, name='admin_home'),
    path('admin/login/', AdminLoginView.as_view(), name='admin_login'),
    path('admin/player/', AdminPlayerView.as_view(), name='admin_player'),
    path('admin/performance/', AdminPerformanceView.as_view(), name='admin_performance'),
    path('admin/team/', AdminTeamView.as_view(), name='admin_team'),

    # api urls
    path('auth/<str:action>/', AuthView.as_view(), name='auth'),
    path('player/', PlayerView.as_view(), name='player'),
    path('team/', TeamView.as_view(), name='team'),
    path('prediction/', PredictionView.as_view(), name='prediction'),
    path('performance/', PerformanceView.as_view(), name='performance'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
