from django.shortcuts import get_object_or_404, render, redirect
from collections import defaultdict
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView
from django.contrib.auth.hashers import check_password
from rest_framework.renderers import TemplateHTMLRenderer, JSONRenderer
from rest_framework.parsers import MultiPartParser, FormParser
from django.utils import timezone
from datetime import timedelta
import random
from rest_framework.response import Response
import numpy as np
import joblib

from .models import *
from .core.serializers import *
from .core.apiResponse import ApiResponse
from .core.utils import deleteImage, send_password_reset_email, send_push_notification
from .core.exceptions import ValidationException, ApiException


# Create your views here.

def getUserByEmail(email):
    user = User.objects.filter(email=email).first()
    if not user:
        raise ApiException("Invalid email address.")
    return user

class AuthView(APIView):
    def post(self, request, *args, **kwargs):
        action = kwargs.get("action")

        if action == "login":
            return self.login(request)
        elif action == "send-otp":
            return self.sendOtp(request)
        elif action == "verify-otp":
            return self.verifyOtp(request)
        else:
            return ApiResponse.error("Invalid action")

    def login(self, request): 
        email = request.data.get('email')
        password = request.data.get('password')
        token = request.data.get('token')
        deviceId = request.data.get('deviceId')
        
        if not email or not password:
            return ApiResponse.error("Both email and password are required")
    
        user = getUserByEmail(email)
    
        if not check_password(password, user.password):
            return ApiResponse.error("Invalid credentials")
        
        if user.user_type != UserType.ADMIN:
            return ApiResponse.error("Invalid credentials")

        FcmToken.objects.update_or_create(
            user=user,
            defaults={
                'user': user,
                'fcm_token': token,
                'device_id': deviceId
            }
        )

        # Send login notification with welcome message
        send_push_notification(token=token, title="Welcome Back!", body=f"Hi {user.name}, you have successfully logged in to Player prediction app.")
        return ApiResponse.success("Login successful", {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "contact": user.contact
        })
    
    def sendOtp(self, request): 
        email = request.data.get("email")
        if not email:
            return ApiResponse.error("Email is required")
        
        user = getUserByEmail(email)
        
        otp_code = random.randint(100000, 999999)
        User.objects.filter(id= user.id).update(
            otp_value= otp_code,
            otp_created_at=timezone.now()
        )
        print("otp value :",otp_code)
        send_password_reset_email(email, otp_code, user.name)
        return ApiResponse.success("OTP sent successfully. Check your email.",email)
    
    def verifyOtp(self, request):
        email = request.data.get("email")
        otp = request.data.get("otp")
        new_password = request.data.get("password")

        if not email or not otp or not new_password:
            return ApiResponse.error("Email,OTP and password are required.")
        
        user = getUserByEmail(email)
        
        # Check if OTP exists and is valid
        if not user.otp_value or str(user.otp_value) != str(otp):
            return ApiResponse.error("Incorrect OTP. Please try again.")
        
        # Check OTP expiration (assuming 10 minutes validity)
        if timezone.now() > user.otp_created_at + timedelta(minutes=10):
            return ApiResponse.error("OTP has expired. Please request a new one.")

        # OTP is valid, reset it in the database
        user.password = make_password(new_password)
        user.otp_value = None
        user.otp_created_at = None
        user.save()

        return ApiResponse.success("Password reset successfully. You can now log in.")

class PlayerView(GenericAPIView):
    queryset = Player.objects.filter(p_is_active= 1).order_by('-id')
    serializer_class = PlayersSerializer
   
    def get(self, request, *args, **kwargs):
        playerId= request.query_params.get("playerId")
        if playerId:
            serializer = self.get_serializer(get_object_or_404(Player, id=playerId),context={"request": request})
            return ApiResponse.success("Player details fetched successfully", serializer.data)
        
        serializer = self.get_serializer(self.get_queryset(), many=True, context={"request": request})
        return ApiResponse.success("Players list fetched successfully", serializer.data)
    
    def post(self, request):
        player_id = request.data.get("playerId")
        select_player = request.data.get("selectPlayer")
        if player_id:
            # Check if player exists
            try:
                player = Player.objects.get(id=player_id)
            except Player.DoesNotExist:
                return ApiResponse.error("Player not found.")
            
            if select_player is not None:
                select_value = str(select_player).lower() == 'true'
                player.p_is_selected = int(select_value)
                player.save(update_fields=['p_is_selected'])

            serializer = self.get_serializer(player, context={"request": request})
            return ApiResponse.success("Player status updated successfully", serializer.data)
       

class TeamView(GenericAPIView):
    queryset = Player.objects.filter(p_is_active=1, p_is_selected=1).order_by('-p_category')
    serializer_class = PlayersSerializer

    def get(self, request, *args, **kwargs):
        serializer = self.get_serializer(self.get_queryset(), many=True, context={"request": request})
        return ApiResponse.success("Team Players grouped by category", serializer.data)

class PerformanceView(GenericAPIView):
    serializer_class = PerformanceSerializer

    def post(self, request):
        player_id = request.data.get('playerId')
        skill_data = request.data.get('data')

        # If 'data' is a list with a stringified dictionary, parse it
        if isinstance(skill_data, list):
            skill_data = skill_data[0]  # Get the first element (string)

        try:
    
            data = {
                "player": player_id,
                "technical_ability": skill_data.get("Technical Ability", {}),
                "tactical_awareness": skill_data.get("Tactical Awareness", {}),
                "physical_aspects": skill_data.get("Physical Aspects", {}),
                "personality_traits": skill_data.get("Personality Traits", {}),
            }

            try:
                # Check if performance already exists for the player
                performance = Performance.objects.get(player_id=player_id)
                serializer = self.serializer_class(performance, data=data, partial=True)
                action = "updated"
            except Performance.DoesNotExist:
                serializer = self.serializer_class(data=data)
                action = "created"

            if serializer.is_valid():
                serializer.save()
                return ApiResponse.success(f"Performance {action} successfully", serializer.data)
                
            raise ValidationException(serializer.errors)
        except Exception as e:
            return ApiResponse.error(f"Invalid data format: {str(e)}")
    


class PredictionView(GenericAPIView):
    def post(self, request):
        player_id = request.data.get("playerId")
        performance = Performance.objects.filter(player_id=player_id).first()

        if not performance:
            return ApiResponse.error("Player performance data not found. Add data to continue")

        # Define the ordered list of skills (based on 'skill_groups' structure)
        skill_order = [
            # Technical Ability
            'ball_control', 'passing', 'dribbling', 'heading', 'finishing',
            # Tactical Awareness
            'in_attack', 'in_defense',
            # Physical Aspects
            'endurance', 'speed', 'agility', 'strength',
            # Personality Traits
            'drive', 'aggressiveness', 'determination', 'responsibility',
            'leadership', 'self_confidence', 'mental_toughness', 'coach_ability',
        ]

        # Flatten all skill categories into a single dictionary
        all_skills = {
            **performance.technical_ability,
            **performance.tactical_awareness,
            **performance.physical_aspects,
            **performance.personality_traits,
        }

        # Create the input list for the model based on the defined skill order
        feature_vector = [all_skills.get(skill, 0) for skill in skill_order]

        # Load the trained model
        model = joblib.load('player_model.pkl')

        # Make prediction
        prediction = model.predict(np.array(feature_vector).reshape(1, -1))
        predicted_value = prediction[0]
        print("Prediction Result:", predicted_value)

        # Return appropriate response
        if predicted_value == 1:
            return ApiResponse.success("Player is a good fit. Do you want to add them to your team?", True)
        else:
            return ApiResponse.success("Player needs further development before joining the team.",False)



# ============================================================ Web actions =============================================================================================

def index(request):
    return render(request, 'index.html')

def logout(request):
    request.session.clear()
    return redirect('index')

class AdminLoginView(APIView):
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = 'admin/login.html'

    def get(self, request):
        return Response(template_name=self.template_name)
    
    def post(self, request,*args, **kwargs):
        email = request.data.get('email')
        password = request.data.get('password')

        if not email or not password:
            return ApiResponse.error("Both email and password are required")
    
        user = getUserByEmail(email)
    
        if not check_password(password, user.password):
            return ApiResponse.error("Invalid credentials")
        
        if user.user_type != UserType.ADMIN:
            return ApiResponse.error("Invalid credentials")
        
        return ApiResponse.success("Login successful")

def adminHome(request):
    return render(request, 'admin/home.html')


class AdminPlayerView(APIView):
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = 'admin/player.html'
    parser_classes = [MultiPartParser, FormParser]  
    serializer_class = PlayersSerializer

    def get(self, request):
        players = Player.objects.all().order_by('-id')
        return Response({"players": players},template_name=self.template_name)
    
    def post(self, request, *args, **kwargs):
        """Handles Create, Update, and Delete based on 'action' parameter"""
        action = request.data.get("action")

        if action == "create":
            return self.create_player(request)
        elif action == "update":
            return self.update_player(request)
        elif action == "delete":
            return self.delete_player(request)
        else:
            return ApiResponse.error("Invalid action specified")
    
    def create_player(self, request):
        """Handles player creation"""
        if not request.data.get('p_image'):
            raise ApiException("Player image is required", status_code=400)    
        
        serializer = self.serializer_class(data=request.data, context={"request": request})
        if serializer.is_valid():
            data = serializer.save()
            return ApiResponse.success("Player added successfully", serializer.data)
        raise ValidationException(serializer.errors)
    
    def update_player(self, request):
        """Handles player update"""
        player_id = request.data.get("player_id")
        if not player_id:
            return ApiResponse.error("Player ID is required for update")

        try:
            player = Player.objects.get(pk=player_id)
        except Player.DoesNotExist:
            return ApiResponse.error("Player not found")

        serializer = self.serializer_class(player, data=request.data, partial=True, context={"request": request})
        if serializer.is_valid():
            serializer.save()
            return ApiResponse.success("Player updated successfully", serializer.data)
        raise ValidationException(serializer.errors)
    
    def delete_player(self, request):
        """Handles player deletion"""
        player_id = request.data.get("player_id")
        if not player_id:
            return ApiResponse.error("Player ID is required for deletion")
        
        try:
            player = Player.objects.get(pk=player_id)
            if player.p_image:
                deleteImage(player.p_image)
            player.delete()
            return ApiResponse.success("Player deleted successfully")
        except Player.DoesNotExist:
            return ApiResponse.error("Player not found")
        

class AdminPerformanceView(APIView):
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = 'admin/performance.html'
    parser_classes = [MultiPartParser, FormParser]  
    serializer_class = PerformanceSerializer

    def get(self, request):
        players = Player.objects.filter(p_is_active=1).order_by('-id')
        return Response({"players": players},template_name=self.template_name)
    
    def post(self, request, *args, **kwargs):
         # Extract player_id
        player_id = request.data.get("player_id")
        if not player_id:
            return ApiResponse.error("Player is required")
        
         # Parse skill group data
        grouped_skills = self.parse_grouped_skills(request.data)

        # Prepare serializer data
        data = {
            "player": player_id,
            "technical_ability": grouped_skills.get("Technical Ability", {}),
            "tactical_awareness": grouped_skills.get("Tactical Awareness", {}),
            "physical_aspects": grouped_skills.get("Physical Aspects", {}),
            "personality_traits": grouped_skills.get("Personality Traits", {}),
        }

        try:
            # Check if performance already exists for the player
            performance = Performance.objects.get(player_id=player_id)
            serializer = self.serializer_class(performance, data=data, partial=True)
            action = "updated"
        except Performance.DoesNotExist:
            serializer = self.serializer_class(data=data)
            action = "created"

        if serializer.is_valid():
            serializer.save()
            return ApiResponse.success(f"Performance {action} successfully", serializer.data)
        raise ValidationException(serializer.errors)

    def parse_grouped_skills(self, post_data):
        grouped = defaultdict(dict)
        for key, value in post_data.items():
            if key.startswith("skills["):
                try:
                    parts = key.replace("skills[", "").rstrip("]").split("][")
                    group = parts[0]
                    field = parts[1]
                    grouped[group][field] = value
                except IndexError:
                    continue
        return dict(grouped)


       
class AdminTeamView(APIView):
    renderer_classes = [JSONRenderer, TemplateHTMLRenderer]
    template_name = 'admin/team.html'

    def get(self, request):
        grouped_players = defaultdict(list)
        for player in Player.objects.filter(p_is_active=1, p_is_selected=1).order_by('-id'):
            grouped_players[player.p_category].append(player)
        return Response({"players": dict(grouped_players)},template_name=self.template_name)



