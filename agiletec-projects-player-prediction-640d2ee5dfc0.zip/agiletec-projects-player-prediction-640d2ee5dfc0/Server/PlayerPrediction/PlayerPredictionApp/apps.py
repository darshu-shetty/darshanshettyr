from django.apps import AppConfig


class PlayerpredictionappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PlayerPredictionApp'
