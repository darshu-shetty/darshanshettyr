from django.db import models
import os
import uuid
def unique_filename(instance, filename, folder):
    """Generates a unique filename in the specified folder."""
    ext = filename.split('.')[-1]
    unique_filename = f"{uuid.uuid4()}.{ext}"
    return os.path.join(f'uploads/{folder}/', unique_filename)
def unique_player_image_filename(instance, filename):
    return unique_filename(instance, filename, "player")
# Create your models here.
class UserType(models.TextChoices):
    USER = 'User', 'User'
    ADMIN = 'Admin', 'Admin'
# Create your models here.

class User(models.Model):
    class Meta:
        db_table = 'users'
        
    user_type = models.CharField(max_length=6, choices=UserType.choices, default=UserType.USER)
    name = models.CharField(blank=False, max_length=50)
    contact = models.CharField(blank=False, max_length=50, unique=True)
    email = models.EmailField(blank=False, max_length=100, unique=True) 
    password = models.CharField(max_length=120)
    otp_value = models.IntegerField(blank=True,null=True, default=None)
    otp_created_at = models.DateTimeField(null=True, blank=True)  # Stores OTP timestamp
    is_active = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class FcmToken(models.Model):
    class Meta:
        db_table = 'fcm_token' 
        unique_together = ('user', 'device_id') 

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='fcm_user') 
    fcm_token = models.TextField(blank=False)
    device_id = models.CharField(max_length=100, blank=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Player(models.Model):
    class Meta:
        db_table='player'

    p_name = models.CharField(max_length=30,default=None)
    p_contact = models.CharField(max_length=12,default=None,blank=False)
    p_email = models.CharField(max_length=100,default=None,blank=False)
    p_age = models.IntegerField(default=None)
    p_address = models.TextField(default=None) 
    p_image = models.ImageField(null=True, default=None, upload_to=unique_player_image_filename)
    p_category = models.CharField(max_length=250,default=None) 
    p_is_active = models.IntegerField(default = 1)    
    p_is_selected = models.IntegerField(default = 0)    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Performance(models.Model):
    class Meta:
        db_table='player_performance'

    player = models.ForeignKey(Player, on_delete=models.CASCADE, related_name='player_performance') 
    technical_ability = models.JSONField()
    tactical_awareness = models.JSONField()
    physical_aspects = models.JSONField()
    personality_traits = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)