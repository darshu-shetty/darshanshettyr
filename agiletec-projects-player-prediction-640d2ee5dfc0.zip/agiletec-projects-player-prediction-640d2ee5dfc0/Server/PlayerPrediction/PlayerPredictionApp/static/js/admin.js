$(document).ready(function () {
    //login
    $('#login_form').submit(function (event) {
        event.preventDefault();
        var formData = new FormData(this);
        UserLogin(formData);
    });


    $('#playerForm').submit(function (event) {
        event.preventDefault();
        var formData = new FormData(this);
        if (!$("#p_image")[0].files.length) {
            formData.delete("p_image");
        }
        showConfirmation("Are you sure you want to complete this action?",
            () => {
                playerAction(formData);
            });
    });
    $('#performanceForm').submit(function (event) {
        event.preventDefault();
        var formData = new FormData(this);
        showConfirmation("Are you sure you want to complete this action?",
            () => {
                performanceAction(formData);
            });
    });

    $('#p_image').change(function () {
        displayImage(this);
    });
})

//  ====================== Auth scripts ==========================================

const UserLogin = (formData) => {
    let formObj = Object.fromEntries(formData);
    PostRequest("/admin/login/", formObj,
        (response) => {
            if (response.status) {
                showSuccess(response.message);
                setTimeout(() => {
                    window.location.href = '/admin/home/';
                }, 2000);
            }
        },
    );
}


//===================================  scripts ====================================

const performanceAction = (formData) => {
    PostRequest("/admin/performance/", formData,
        (response) => {
            if (response.status) {
                showSuccess(response.message);
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            }
        }, true
    );
}

const playerAction = (formData) => {
    PostRequest("/admin/player/", formData,
        (response) => {
            if (response.status) {
                showSuccess(response.message);
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            }
        }, true
    );
}

const deletePlayer = (stationId) => {
    const formData = new FormData();
    formData.append("action", "delete")
    formData.append("player_id", stationId)
    showConfirmation("Are you sure you want to delete this station?",
        () => {
            playerAction(formData);
        });
}

function addPlayer() {
    $('#playerForm')[0].reset();
    $('#previewImage').attr('src', '/media/user.png')
    $('#action').val("create")
    addEditPlayerModel("Add")
}

function editPlayer(...stationData) {
    $('#playerForm')[0].reset();
    $('#action').val("update")
    Object.entries(stationData[0]).forEach(([key, value]) => {
        if (key === "image_url") {
            $('#previewImage').attr('src', value)
        } else {
            $(`#${key}`).val(value);
        }
    });
    addEditPlayerModel("Edit")
}

function addEditPlayerModel(type) {
    $('.offcanvas-title').text(`${type} Player`);
    var myOffcanvas = document.getElementById('offcanvasExample')
    var bsOffcanvas = new bootstrap.Offcanvas(myOffcanvas)
    bsOffcanvas.show()
}

const displayImage = (input) => {
    var previewImage = $('#previewImage')[0];
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            previewImage.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

