$(document).ready(function () {
    $.ajaxSetup({
        beforeSend: function (xhr, settings) {
            if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
                xhr.setRequestHeader("X-CSRFToken", $("[name=csrfmiddlewaretoken]").val());
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error("AJAX Error:", textStatus, errorThrown);
            const response = JSON.parse(jqXHR.responseText)
            showError(response.message)
        }
    });
});

// GET Request
const GetRequest = (url, successCallback, has_params = false, data = null) => {
    var ajaxOptions = {
        type: 'GET',
        url: url,
        success: successCallback,
    };

    if (has_params) {
        ajaxOptions.data = data;
    }

    $.ajax(ajaxOptions);
}

// POST Request (Handles JSON & File Uploads)
const PostRequest = (url, data, successCallback, has_file = false) => {
    var ajaxOptions = {
        type: 'POST',
        url: url,
        data: data,
        success: successCallback,
    };

    if (has_file) {
        ajaxOptions.contentType = false;
        ajaxOptions.processData = false;
    } else {
        ajaxOptions.contentType = 'application/json';
        ajaxOptions.data = JSON.stringify(data); // Convert to JSON
    }

    $.ajax(ajaxOptions);
}
