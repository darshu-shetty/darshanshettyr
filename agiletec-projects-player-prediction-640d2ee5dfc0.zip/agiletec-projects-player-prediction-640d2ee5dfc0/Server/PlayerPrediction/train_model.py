import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import joblib

# Load and prepare data
dataset = pd.read_csv('player_dataset.csv')
X = dataset.iloc[:, :-1].values.astype(int)
Y = dataset.iloc[:, -1].values

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.25, random_state=42)

# Train model
model_RR = RandomForestClassifier(n_estimators=100, criterion='entropy')
model_RR.fit(X_train, y_train)

# --- Evaluation on Test Data ---
y_pred = model_RR.predict(X_test)

# Accuracy
acc = accuracy_score(y_test, y_pred)
print("Accuracy:", acc)

# Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", conf_matrix)

# Save model to pkl
joblib.dump(model_RR, 'player_model.pkl')
